﻿using PDCA_Sender.Services;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Path = System.IO.Path;

namespace PDCA_Sender
{
    public partial class MainWindow : Window
    {
        private readonly TcpService _tcpService;
        private bool _isAutoSending = false;
        private const int MlbLength = 18;

        private string ConfigPath =>
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "server.txt");

        private string TemplatePath =>
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Templates", "pdca_template.txt");

        private string LogFolderPath =>
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");

        public MainWindow()
        {
            InitializeComponent();
            _tcpService = new TcpService();
            LoadServerConfig();
            LoadTemplate();
        }

        private void LoadServerConfig()
        {
            try
            {
                if (!File.Exists(ConfigPath)) return;

                string[] lines = File.ReadAllLines(ConfigPath);
                foreach (string line in lines)
                {
                    if (line.StartsWith("IP="))
                        txtIp.Text = line.Substring(3).Trim();
                    else if (line.StartsWith("PORT="))
                        txtPort.Text = line.Substring(5).Trim();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Config Error:\n" + ex.Message);
            }
        }

        private void LoadTemplate()
        {
            try
            {
                if (!File.Exists(TemplatePath)) return;
                txtPdcaData.Text = File.ReadAllText(TemplatePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Template Error:\n" + ex.Message);
            }
        }

        private string GeneratePdcaData(string template, string mlbSerial, string carrierSerial)
        {
            string[] lines = template.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                if (string.IsNullOrWhiteSpace(line)) continue;

                int firstAtIndex = line.IndexOf('@');
                if (firstAtIndex > 0)
                {
                    line = mlbSerial + line.Substring(firstAtIndex);
                }

                if (line.Contains("@Carrier_SN@"))
                {
                    string[] parts = line.Split('@');
                    if (parts.Length >= 3)
                    {
                        parts[parts.Length - 1] = carrierSerial;
                        line = string.Join("@", parts);
                    }
                }

                if (line.Contains("@pallet_sn@"))
                {
                    string[] parts = line.Split('@');
                    if (parts.Length >= 3)
                    {
                        parts[2] = carrierSerial;
                        line = string.Join("@", parts);
                    }
                }

                lines[i] = line;
            }

            return string.Join("\r\n", lines);
        }

        private void WriteLogFile(string mlbSerial)
        {
            try
            {
                if (!Directory.Exists(LogFolderPath))
                {
                    Directory.CreateDirectory(LogFolderPath);
                }

                string dateStr = DateTime.Now.ToString("yyyy-MM-dd");
                string logFileName = $"Log_{dateStr}.txt";
                string fullPath = Path.Combine(LogFolderPath, logFileName);

                // Format: 1,DateTime,MLB_SN
                string timeStamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                string logLine = $"1,{timeStamp},{mlbSerial}\r\n";

                File.AppendAllText(fullPath, logLine);
            }
            catch (Exception ex)
            {
                // Ignore or handle log write error if needed
            }
        }

        private void SetResponseColor(bool isSuccess)
        {
            if (isSuccess)
            {
                // Green background for Success
                txtResponse.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#137333"));
                txtResponse.Foreground = Brushes.White;
            }
            else
            {
                // Red background for Fail
                txtResponse.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#A50E0E"));
                txtResponse.Foreground = Brushes.White;
            }
        }

        private void Generate_Click(object sender, RoutedEventArgs e)
        {
            GenerateManualData();
        }

        private bool GenerateManualData()
        {
            try
            {
                string carrier = txtCarrierSn.Text.Trim();
                string mlb = txtMlbSn.Text.Trim();

                if (string.IsNullOrWhiteSpace(carrier))
                {
                    MessageBox.Show("Enter Carrier Serial Number.");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(mlb))
                {
                    MessageBox.Show("Enter MLB Serial Number.");
                    return false;
                }

                if (mlb.Length != MlbLength)
                {
                    MessageBox.Show("MLB Serial Number must be exactly 18 characters.");
                    return false;
                }

                string template = File.ReadAllText(TemplatePath);
                txtPdcaData.Text = GeneratePdcaData(template, mlb, carrier);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generate Error:\n" + ex.Message);
                return false;
            }
        }

        private void Mode_Changed(object sender, RoutedEventArgs e)
        {
            if (!IsLoaded) return;

            bool autoMode = rbAuto.IsChecked == true;
            btnGenerate.IsEnabled = !autoMode;
            btnSend.IsEnabled = !autoMode;

            // Reset box background on mode change
            txtResponse.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#303134"));
            txtResponse.Foreground = Brushes.White;

            if (autoMode)
            {
                txtResponse.Text = "AUTO mode ready.\r\nEnter Carrier SN and scan 18-character MLB SN.";
                txtMlbSn.Focus();
            }
            else
            {
                txtResponse.Text = "MANUAL mode.";
                txtMlbSn.Focus();
            }
        }

        private async void txtMlbSn_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!IsLoaded) return;
            if (rbAuto.IsChecked != true) return;
            if (_isAutoSending) return;

            string mlb = txtMlbSn.Text.Trim();
            if (mlb.Length != MlbLength) return;

            if (string.IsNullOrWhiteSpace(txtCarrierSn.Text))
            {
                txtResponse.Text = "Enter Carrier Serial Number first.";
                return;
            }

            await AutoGenerateAndSendAsync();
        }

        private async Task AutoGenerateAndSendAsync()
        {
            if (_isAutoSending) return;
            _isAutoSending = true;

            try
            {
                string mlb = txtMlbSn.Text.Trim();
                string carrier = txtCarrierSn.Text.Trim();

                if (mlb.Length != MlbLength || string.IsNullOrWhiteSpace(carrier))
                {
                    return;
                }

                int port;
                if (!int.TryParse(txtPort.Text, out port))
                {
                    txtResponse.Text = "Invalid server port.";
                    return;
                }

                string template = File.ReadAllText(TemplatePath);
                txtPdcaData.Text = GeneratePdcaData(template, mlb, carrier);

                txtResponse.Text = "Sending...";
                txtMlbSn.IsEnabled = false;

                string response = await _tcpService.SendAsync(txtIp.Text.Trim(), port, txtPdcaData.Text);

                if (IsSuccessfulResponse(response))
                {
                    // Write to log file on success
                    WriteLogFile(mlb);
                    SetResponseColor(true);

                    txtMlbSn.IsEnabled = true;
                    txtMlbSn.Clear();
                    txtMlbSn.Focus();
                    txtResponse.Text = "SUCCESS\r\n\r\n" + response;
                }
                else
                {
                    SetResponseColor(false);
                    txtMlbSn.IsEnabled = true;
                    txtMlbSn.Focus();
                    txtMlbSn.SelectAll();
                    txtResponse.Text = "FAILED\r\n\r\n" + response;
                }
            }
            catch (Exception ex)
            {
                SetResponseColor(false);
                txtMlbSn.IsEnabled = true;
                txtResponse.Text = "ERROR:\r\n" + ex.Message;
                txtMlbSn.Focus();
                txtMlbSn.SelectAll();
            }
            finally
            {
                _isAutoSending = false;
                txtMlbSn.IsEnabled = true;
            }
        }

        private bool IsSuccessfulResponse(string response)
        {
            if (string.IsNullOrWhiteSpace(response)) return false;
            string result = response.Trim().ToUpper();
            return result.Contains("SUCCESS") || result.Contains("PASS") || result.Contains("OK");
        }

        private async void TestConnection_Click(object sender, RoutedEventArgs e)
        {
            int port;
            if (!int.TryParse(txtPort.Text, out port))
            {
                MessageBox.Show("Invalid port.");
                return;
            }

            bool connected = await _tcpService.TestConnectionAsync(txtIp.Text.Trim(), port);
            if (connected)
            {
                MessageBox.Show("Server connection successful.");
            }
            else
            {
                MessageBox.Show("Unable to connect to server.");
            }
        }

        private async void Send_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (rbAuto.IsChecked == true) return;

                if (string.IsNullOrWhiteSpace(txtPdcaData.Text))
                {
                    MessageBox.Show("No PDCA data to send.");
                    return;
                }

                int port;
                if (!int.TryParse(txtPort.Text, out port))
                {
                    MessageBox.Show("Invalid port.");
                    return;
                }

                txtResponse.Text = "Sending...";
                btnSend.IsEnabled = false;

                string response = await _tcpService.SendAsync(txtIp.Text.Trim(), port, txtPdcaData.Text);
                txtResponse.Text = response;

                if (IsSuccessfulResponse(response))
                {
                    string mlb = txtMlbSn.Text.Trim();
                    if (!string.IsNullOrEmpty(mlb))
                    {
                        WriteLogFile(mlb);
                    }
                    SetResponseColor(true);
                    txtResponse.Text = "SUCCESS\r\n\r\n" + response;
                }
                else
                {
                    SetResponseColor(false);
                    txtResponse.Text = "FAILED\r\n\r\n" + response;
                }
            }
            catch (Exception ex)
            {
                SetResponseColor(false);
                txtResponse.Text = "ERROR:\r\n" + ex.Message;
            }
            finally
            {
                if (rbManual.IsChecked == true)
                {
                    btnSend.IsEnabled = true;
                }
            }
        }
    }
}