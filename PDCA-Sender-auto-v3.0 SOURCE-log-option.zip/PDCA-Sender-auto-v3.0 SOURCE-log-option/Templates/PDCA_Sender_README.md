# PDCA Sender - Developer README

## 1. Overview

**PDCA Sender** is a simple Windows desktop application built with:

- C#
- WPF
- .NET Framework 4.8
- x86 target

The application is designed to manually prepare PDCA data for one MLB board, send the data to a PDCA server over TCP/IP, and display the server response.

Main workflow:

1. Application starts.
2. Server IP and Port are loaded from `Config/server.txt`.
3. PDCA sample/template data is loaded from `Templates/pdca_template.txt`.
4. User enters:
   - Carrier Serial Number
   - MLB Serial Number
5. User clicks **Generate**.
6. The template is updated with the entered serial numbers.
7. Generated PDCA data is shown in the UI and can be manually edited.
8. User clicks **Test Connection** to verify that the TCP server is reachable.
9. User clicks **Send**.
10. The application opens a TCP connection, sends the PDCA text, waits for a response, and displays the response.

---

## 2. Project Structure

Recommended structure:

```text
PDCA_Sender
|
|-- MainWindow.xaml
|-- MainWindow.xaml.cs
|
|-- Services
|   `-- TcpService.cs
|
|-- Config
|   `-- server.txt
|
`-- Templates
    `-- pdca_template.txt
```

### Files

#### `MainWindow.xaml`

Contains the WPF user interface.

Main controls include:

- Server IP
- Server Port
- Carrier Serial Number
- MLB Serial Number
- Test Connection button
- Generate button
- Editable PDCA data area
- Send button
- Server response area

#### `MainWindow.xaml.cs`

Contains:

- Loading server settings
- Loading PDCA template
- PDCA data generation
- MLB serial number replacement
- Carrier serial number replacement
- Input validation
- Test Connection action
- Send action
- Displaying server response

#### `Services/TcpService.cs`

Contains the TCP communication code:

- `TestConnectionAsync()`
- `SendAsync()`

#### `Config/server.txt`

Contains PDCA server connection information.

Example:

```text
IP=192.168.1.100
PORT=5000
```

For local testing on the same computer:

```text
IP=127.0.0.1
PORT=5000
```

#### `Templates/pdca_template.txt`

Contains dummy/sample PDCA data used to generate the final request.

---

# 3. Application Startup

When `MainWindow` is created:

```csharp
public MainWindow()
{
    InitializeComponent();

    _tcpService = new TcpService();

    LoadServerConfig();
    LoadTemplate();
}
```

The application automatically:

1. Creates the TCP service.
2. Reads `Config/server.txt`.
3. Reads `Templates/pdca_template.txt`.
4. Displays the loaded values in the UI.

The file paths are created from the EXE directory:

```csharp
AppDomain.CurrentDomain.BaseDirectory
```

Therefore, after building the application, the following folders should exist beside the EXE:

```text
PDCA_Sender.exe
Config
    server.txt
Templates
    pdca_template.txt
```

In Visual Studio, set both text files to:

```text
Build Action: Content
Copy to Output Directory: Copy if newer
```

---

# 4. Server Configuration

The server configuration is read from:

```text
Config/server.txt
```

Current format:

```text
IP=192.168.1.100
PORT=5000
```

The following code reads these values:

```csharp
if (line.StartsWith("IP="))
{
    txtIp.Text = line.Substring(3).Trim();
}

else if (line.StartsWith("PORT="))
{
    txtPort.Text = line.Substring(5).Trim();
}
```

## If the PDCA server changes

Update `server.txt`.

Example:

```text
IP=192.168.31.10
PORT=7001
```

No code change is required if only the IP address or port changes.

---

# 5. PDCA Template Format

The current application expects PDCA template lines to follow this general structure:

```text
MLB_SERIAL_NUMBER@KEY@VALUE
```

Example:

```text
SAMPLE_MLB@Carrier_SN@SAMPLE_CARRIER
SAMPLE_MLB@pallet_sn@SAMPLE_CARRIER
SAMPLE_MLB@mask_sn@MASK001
SAMPLE_MLB@button_flex_sn@FLEX001
SAMPLE_MLB@machine_id@LG000
SAMPLE_MLB@tossing@1
SAMPLE_MLB@nozzle_number@2
SAMPLE_MLB@cycle_time@30
```

The text before the **first `@`** is treated as the MLB Serial Number field.

---

# 6. MLB Serial Number Replacement

The application processes every non-empty template line.

Example template:

```text
SAMPLE_MLB@machine_id@LG000
```

If the user enters:

```text
MLB Serial Number = F2L123456789
```

The generated result becomes:

```text
F2L123456789@machine_id@LG000
```

The code works by finding the first `@`:

```csharp
int firstAtIndex = line.IndexOf('@');
```

Then everything before it is replaced:

```csharp
line =
    mlbSerial +
    line.Substring(firstAtIndex);
```

Therefore:

```text
OLD_VALUE@machine_id@LG000
```

becomes:

```text
USER_MLB_SN@machine_id@LG000
```

This is done for every non-empty line containing `@`.

---

# 7. Carrier Serial Number Replacement

Currently two PDCA keys are treated as Carrier Serial Number values:

```text
@Carrier_SN@
```

and:

```text
@pallet_sn@
```

Example template:

```text
SAMPLE_MLB@Carrier_SN@OLD_CARRIER
```

User enters:

```text
Carrier SN = CARRIER987654
```

Generated result:

```text
USER_MLB_SN@Carrier_SN@CARRIER987654
```

The same replacement is currently done for:

```text
USER_MLB_SN@pallet_sn@CARRIER987654
```

The code uses:

```csharp
string[] parts = line.Split('@');

if (parts.Length >= 3)
{
    parts[2] = carrierSerial;
    line = string.Join("@", parts);
}
```

## Important

The current code replaces **the third field (`parts[2]`) only**.

The expected structure is therefore:

```text
MLB@KEY@VALUE
```

If the real PDCA protocol uses another structure, this logic must be reviewed.

---

# 8. Generate Button

When the user clicks **Generate**:

1. Carrier SN is read.
2. MLB SN is read.
3. Empty input is rejected.
4. `pdca_template.txt` is loaded again.
5. `GeneratePdcaData()` is called.
6. Final generated data is displayed in `txtPdcaData`.

Because the generated data is shown in an editable TextBox, the user can manually modify it before sending.

---

# 9. Test Connection

`TestConnectionAsync()` checks whether a TCP connection can be opened.

```csharp
public async Task<bool> TestConnectionAsync(
    string ip,
    int port)
```

The connection timeout is currently:

```text
3 seconds
```

Implemented using:

```csharp
Task.Delay(3000)
```

If the TCP connection succeeds:

```text
Server connection successful.
```

If it fails:

```text
Unable to connect to server.
```

## Important

A successful Test Connection means only:

> A TCP listener is available at the specified IP and Port.

It does **not** confirm:

- PDCA format is correct.
- Login/authentication is correct.
- Server accepted the PDCA data.
- Server database update succeeded.
- Message terminator is correct.
- Encoding is correct.

---

# 10. Sending PDCA Data

Current send flow:

```text
WPF Application
      |
      | TCP Connect
      v
PDCA Server
      |
      | UTF-8 PDCA text
      v
Server processes data
      |
      | Response
      v
WPF Application
```

The application creates a new `TcpClient` for every Send operation:

```csharp
using (TcpClient client = new TcpClient())
{
    await client.ConnectAsync(ip, port);
}
```

It then gets the network stream:

```csharp
NetworkStream stream =
    client.GetStream();
```

The outgoing PDCA text is currently converted to:

```text
UTF-8
```

using:

```csharp
Encoding.UTF8.GetBytes(data);
```

The complete TextBox contents are sent exactly as shown in the UI.

---

# 11. Receiving the Server Response

After sending, the application waits for the server to return data:

```csharp
int received =
    await stream.ReadAsync(
        buffer,
        0,
        buffer.Length);
```

Current receive buffer size:

```text
8192 bytes
```

The response is decoded using UTF-8:

```csharp
Encoding.UTF8.GetString(...)
```

and displayed in:

```text
Server Response
```

If the server closes the connection without sending anything:

```text
No response received.
```

is displayed.

---

# 12. Current TCP Assumptions

The current version assumes all of the following:

### Protocol

```text
Raw TCP
```

Not:

- HTTP
- HTTPS
- REST API
- WebSocket
- UDP

### Encoding

```text
UTF-8
```

### Connection model

```text
Connect -> Send -> Receive -> Close
```

A new connection is created for every Send operation.

### Response

The program expects the server to return a response after the request is sent.

### Receive size

The first response read is limited to:

```text
8192 bytes
```

### Message termination

The current code does **not automatically add**:

```text
\r\n
```

or:

```text
\n
```

or:

```text
\0
```

or any STX/ETX characters.

The PDCA text is sent exactly as it appears in the TextBox.

This must be verified against the real PDCA server protocol.

---

# 13. Information Required Before Connecting to the Real PDCA Server

Before using the application with the actual production PDCA server, confirm the following with the PDCA/server team.

## Network Information

Required:

```text
Server IP:
Server Port:
```

Example:

```text
Server IP: 192.168.100.20
Server Port: 5000
```

Also confirm:

- PC can ping/reach the server.
- Windows Firewall permits the connection.
- Network/VLAN permits the connection.
- Correct Ethernet adapter/network is being used.

---

# 14. Communication Protocol Information

Confirm whether the server uses:

```text
TCP
UDP
HTTP
HTTPS
WebSocket
Other
```

The current application supports:

```text
TCP
```

If the actual server uses another protocol, `TcpService.cs` must be changed.

---

# 15. Encoding

Ask the server developer which text encoding is expected.

Possible values:

```text
ASCII
UTF-8
UTF-16
EUC-KR
Other
```

Current application:

```csharp
Encoding.UTF8
```

If ASCII is required, change:

```csharp
Encoding.UTF8.GetBytes(data);
```

to:

```csharp
Encoding.ASCII.GetBytes(data);
```

and change the response decoding similarly.

---

# 16. Message Terminator / End Character

This is very important.

Ask how the server knows that one PDCA command/request is complete.

Possible formats include:

```text
\r\n
```

or:

```text
\n
```

or:

```text
\0
```

or:

```text
STX + DATA + ETX
```

or:

```text
Length Header + DATA
```

or the server may process data immediately without a terminator.

Current application sends:

```text
DATA
```

exactly as provided.

If CRLF is required, for example:

```csharp
data = data + "\r\n";
```

must be added before converting to bytes.

---

# 17. PDCA Command Format

Before production use, obtain at least one real working request from the existing machine or another vendor.

Ideally obtain:

```text
Real Request
Real Success Response
Real Failure Response
```

Example information required:

```text
START command format
DUT position command format
ATTR command format
PDATA command format
SUBMIT command format
```

The current dummy template must eventually match the exact output format generated by the production functions such as:

```csharp
GetStartCommand(...)
GetDutPosCommand(...)
GetAttrCommand(...)
GetPdataCommand(...)
GetSubmitCommand(...)
```

---

# 18. Verify Serial Number Meaning

The original machine code uses several values:

```text
SerialNumber
SubSN
CarrierSN
UnitSN
mask_sn
```

Before final deployment, confirm which serial number belongs in each PDCA command.

In particular, confirm:

```text
Is SerialNumber the MLB Serial Number?
```

and:

```text
Does GetStartCommand(SubSN) use MLB SN or another SubSN?
```

The current manual application assumes the first field of each template line should use the user-entered MLB Serial Number.

If some commands use a different serial number, those lines must be handled separately.

---

# 19. Verify Carrier Fields

Current application replaces Carrier SN in:

```text
Carrier_SN
pallet_sn
```

Confirm whether both are actually supposed to contain the same Carrier Serial Number.

If more PDCA fields must use the Carrier SN, add them to `GeneratePdcaData()`.

Example:

```csharp
if (line.Contains("@another_carrier_field@"))
{
    ...
}
```

---

# 20. Server Response Format

Ask the PDCA server team what the response means.

For example:

Success could be:

```text
OK
PASS
ACK
SUCCESS
0
```

Failure could be:

```text
NG
FAIL
NACK
ERROR
-1
```

The current program does not interpret the response.

It simply displays the raw response received from the server.

For production use, it may be useful later to implement:

```text
Green = Success
Red = Failure
```

based on the actual response specification.

---

# 21. Response Timing

Current `SendAsync()` does not have a separate receive timeout.

After successfully connecting and sending data, this line waits for a server response:

```csharp
await stream.ReadAsync(...)
```

If the real server keeps the connection open but never sends a response, the application may continue waiting.

Recommended future improvement:

```text
Receive timeout = 3 to 10 seconds
```

depending on the PDCA server specification.

---

# 22. Multi-Packet Responses

The current application performs one:

```csharp
ReadAsync()
```

operation.

That is enough for simple small responses such as:

```text
OK
```

but TCP does not guarantee that a complete logical message arrives in one read.

If the PDCA server returns a large or multi-part response, the receive implementation should be changed to continue reading until one of these conditions is met:

- End delimiter received
- Expected length received
- Server closes connection
- Timeout occurs

The correct method depends on the server protocol.

---

# 23. Local Testing

For development, the application can be tested locally using a TCP test server.

Configuration:

```text
IP=127.0.0.1
PORT=5000
```

`127.0.0.1` means the same computer.

Test flow:

```text
PDCA Sender
    |
    | TCP 127.0.0.1:5000
    v
Local TCP Test Server
    |
    | Receives PDCA
    |
    | Returns PDCA_OK
    v
PDCA Sender
```

Expected UI response:

```text
PDCA_OK
```

If the local server receives the request but does not send anything back, the application may show:

```text
No response received.
```

This does not necessarily mean the Send failed. It can mean the server accepted the TCP data and then closed the connection without returning data.

---

# 24. Example Development Test

## server.txt

```text
IP=127.0.0.1
PORT=5000
```

## Template

```text
SAMPLE_MLB@Carrier_SN@SAMPLE_CARRIER
SAMPLE_MLB@pallet_sn@SAMPLE_CARRIER
SAMPLE_MLB@machine_id@LG000
SAMPLE_MLB@cycle_time@30
```

## User input

```text
MLB SN:
MLB123456789

Carrier SN:
CARRIER987654
```

## Generated result

```text
MLB123456789@Carrier_SN@CARRIER987654
MLB123456789@pallet_sn@CARRIER987654
MLB123456789@machine_id@LG000
MLB123456789@cycle_time@30
```

This generated text is what will be sent to the TCP server.

---

# 25. Important Files to Check During Deployment

The deployed folder should contain:

```text
PDCA_Sender.exe
PDCA_Sender.exe.config

Config
    server.txt

Templates
    pdca_template.txt
```

If `server.txt` is missing:

```text
server.txt not found.
```

will be shown.

If `pdca_template.txt` is missing:

```text
PDCA template file not found.
```

will be shown.

---

# 26. Troubleshooting

## Unable to connect to server

Check:

```text
IP address
Port
Server running
Firewall
Network/VLAN
Ping/reachability
TCP listener
```

A port entered in a test tool does not automatically mean a TCP server is listening on that port.

---

## Test Connection works, but Send does not

Check:

```text
PDCA message format
Encoding
Message terminator
Server response behavior
Server application logs
```

This usually means the network connection is available, but the application protocol may be incorrect.

---

## Server receives data but WPF shows no response

The server may not return a response.

Confirm whether a response is expected.

If using a test server, configure it to return something such as:

```text
PDCA_OK
```

---

## Wrong MLB Serial Number

Check `GeneratePdcaData()`.

Every non-empty template line with `@` currently has everything before the first `@` replaced with the entered MLB Serial Number.

---

## Wrong Carrier Serial Number

Check whether the template key exactly contains:

```text
@Carrier_SN@
```

or:

```text
@pallet_sn@
```

The current matching is case-sensitive.

For example:

```text
@carrier_sn@
```

will not match:

```text
@Carrier_SN@
```

---

# 27. Recommended Improvements Before Production

The current application is suitable for initial/manual testing.

Before production use, consider adding:

1. Receive timeout
2. Send timeout
3. Logging
4. Timestamp for every request
5. Save request and response
6. Success/Failure response parsing
7. Disable Send while request is running
8. Serial number format validation
9. Server connection status indicator
10. Confirmation before Send
11. Prevent accidental duplicate submission
12. Daily log file
13. Better exception details
14. Configurable encoding
15. Configurable message terminator

---

# 28. Developer Checklist When Server Specification Changes

If the PDCA server changes, check these items in order:

```text
[ ] Server IP
[ ] Server Port
[ ] TCP / UDP / HTTP protocol
[ ] Encoding
[ ] Message format
[ ] Field delimiter
[ ] Line delimiter
[ ] End-of-message delimiter
[ ] Start command
[ ] Submit command
[ ] Required MLB field
[ ] Required Carrier field
[ ] Response format
[ ] Success code
[ ] Failure code
[ ] Receive timeout
[ ] Persistent or one-request-per-connection behavior
[ ] Authentication, if any
```

---

# 29. Most Important Information to Request from PDCA Team

For the developer, the most useful information is a captured example from a known working machine.

Request:

```text
1. Server IP
2. Server Port
3. Protocol
4. Encoding
5. Complete raw request example
6. Complete raw success response
7. Complete raw failure response
8. End-of-message character/delimiter
9. Whether one connection is used for one MLB or multiple MLBs
10. Meaning and source of SerialNumber, SubSN and CarrierSN
```

With these details, `TcpService.cs` and the PDCA template can be made compatible with the actual production server.

---

# 30. Current Implementation Summary

Current application behavior:

```text
Load server.txt
        |
Load pdca_template.txt
        |
Enter Carrier SN + MLB SN
        |
Generate
        |
Replace first field of every PDCA line with MLB SN
        |
Replace Carrier_SN and pallet_sn values with Carrier SN
        |
Show editable final request
        |
Test TCP connection
        |
Send UTF-8 raw TCP data
        |
Read up to 8192 bytes
        |
Display server response
```

This design intentionally keeps the application simple so that server information and PDCA sample data can be changed without rebuilding the WPF application whenever possible.
